﻿using ApplicationUnderTest.Pages;
using Microsoft.Extensions.DependencyInjection;
using TestFramework.Config;


namespace ApplicationUnderTest
{
    public class Startup
    {
        public void ConfigureServices(IServiceCollection services)
        {
            services
                .AddSingleton(ConfigReader.ReadConfig())
                .AddScoped<IDriverFixture, DriverFixture>()
                .AddScoped<IDriverWait, DriverWait>()
                .AddScoped<IHomePage, HomePage>();
        }
    }
}
