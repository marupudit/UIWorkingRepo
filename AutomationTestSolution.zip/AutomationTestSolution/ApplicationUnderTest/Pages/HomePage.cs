﻿using OpenQA.Selenium;
using TestFramework.Driver;

namespace ApplicationUnderTest.Pages
{
    public interface IHomePage
    {
        void AcceptCookies();
        void ClickSign();
    }

    public class HomePage : IHomePage
    {
        private readonly IDriverWait _driver;
        public HomePage(IDriverWait driver)
        {
            _driver = driver;
        }
        private IWebElement btnSignIn => _driver.FindElement(By.XPath("//span[normalize-space()='Sign in']"));
        private IWebElement _btnAcceptCookies => _driver.FindElement(By.Id("ccc-notify-accept"));

        public void ClickSign() => btnSignIn.Click();
        public void AcceptCookies()
        {
            //_btnAcceptCookies.WaitForElementIsVisible(TimeoutInSeconds.DefaultTimeout);
            _btnAcceptCookies.Click();
        }

    }
}
