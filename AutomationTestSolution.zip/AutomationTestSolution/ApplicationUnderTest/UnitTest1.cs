using ApplicationUnderTest.Pages;

namespace ApplicationUnderTest
{
    public class UnitTest1
    {
        private readonly IHomePage _homePage;

        public IDriverFixture DriverFixture { get; }

        public UnitTest1(IHomePage homePage) {
            _homePage = homePage;
        }

        [Fact]
        public void Test1()
        {
            _homePage.AcceptCookies();
            _homePage.ClickSign();
        }
    }
}