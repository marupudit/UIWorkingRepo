﻿using NUnit.Framework;
using OSBaseAutoFramework.Helpers;
using OSDataHubUIProject.Pages;
using PGSAEndToEndBaseProject.Config;
using SpecFlowProjectNUnit.Pages;
using System.Data;
using TestFramework.Config;

namespace OSDataHubUIProject.StepDefinitions
{
    [Binding]
    public class DownloadDataFilesSteps 
    {
        private readonly ScenarioContext _scenarioContext;
        private readonly IDownloadDataFilesPage _downloadDataFilesPage;
        private readonly IDataHubUILoginPage _dataHubUILoginPage;
        private static string baseDownloadFileLocation;
        private readonly DefaultSettings _testSettings;

        public DownloadDataFilesSteps(ScenarioContext scenarioContext, IDownloadDataFilesPage downloadDataFilesPage, DefaultSettings testsettings)
        {
            _scenarioContext = scenarioContext;
            _downloadDataFilesPage = downloadDataFilesPage;
            _testSettings = testsettings;
        }

        [StepDefinition(@"I verified the '([^']*)' Individual files are available to download")]
        public void ThenIVerifiedTheIndividualFilesAreAvailableToDownload(int downloadFilesCount)
        {
            Assert.AreEqual(downloadFilesCount, _downloadDataFilesPage.GetAvailableDownloadFilesCount());
        }

        [StepDefinition(@"I verified the ""([^""]*)"" Individual files are available to download")]
        public void ThenIVerifiedTheIndividualFilesAreAvailableToDownload(string downloadFilesCount)
        {
            Assert.AreEqual(Int32.Parse(downloadFilesCount), _downloadDataFilesPage.GetAvailableDownloadFilesCount());
        }

        [StepDefinition(@"I can download and unzip the following Individual files")]
        public void ThenICanDownloadAndUnzipTheFollowingIndividualFiles(Table downloadFileNamesTable)
        {
            var stepType = _scenarioContext.ScenarioInfo.Title.Trim().ToString();
            String[] scenarioTitle = stepType.Split(":");
            foreach (string fileName in Utilities.ConvertTableToList(downloadFileNamesTable))
            {
                _downloadDataFilesPage.DownloadDataFilesFromDataHub(fileName);
                String[] fileNameSplitter = fileName.Split(".");
                if(fileNameSplitter[1] == "zip")
                {
                    _downloadDataFilesPage.UnzippedTheDownloadedFiles(scenarioTitle[0],fileName);
                }
                else
                {
                    _downloadDataFilesPage.MoveTheFilesDownloadedFiles(scenarioTitle[0], fileName);
                }  
              
            }
        }

        [StepDefinition(@"I can download and unzip the following Individual files ""([^""]*)""")]
        public void ThenICanDownloadAndUnzipTheFollowingIndividualFiles(string fileNames)
        {
            var stepType = _scenarioContext.ScenarioInfo.Title.Trim().ToString();
            String[] scenarioTitle = stepType.Split(":");
            _downloadDataFilesPage.DownloadDataFilesFromDataHub(fileNames);
            String[] fileNameSplitter = fileNames.Split(".");
            if (fileNameSplitter[1] == "zip")
            {
                _downloadDataFilesPage.UnzippedTheDownloadedFiles(scenarioTitle[0], fileNames);
            }
            else
            {
                _downloadDataFilesPage.MoveTheFilesDownloadedFiles(scenarioTitle[0], fileNames);
            }
        }

        [StepDefinition(@"I open the ""([^""]*)"" test scenario file location for ""([^""]*)"" date")]
        public void GivenIOpenTheTestScenarioFileLocationForDate(string scenarioNumber, string folderDate)
        {
            baseDownloadFileLocation = FilePathForDownloadedFiles(scenarioNumber, folderDate);
        }


        [StepDefinition(@"I verified the data in ""([^""]*)"" csv")]
        public void GivenIVerifiedTheDataInCsv(string fileName, Table expectedBddTable)
        {
            //string strFilePath = $"C:\\Users\\TMarupudi\\source\\repos\\PGSAEndToEndTestSolution\\OSDataHubUIProject\\DownloadedFiles\\2022_12_19\\AC07\\{fileName}";
            baseDownloadFileLocation = FilePathForDownloadedFiles("AC07", "2022_12_19");
            string strFilePath = $"{baseDownloadFileLocation}\\{fileName}";
            DataTable dt = ExcelHelpers.ConvertCSVtoDataTable(strFilePath);
            var colnName = dt.Columns;
            DataTable bddExpectedDataTable = ExcelHelpers.ConvertBDDTableToDataTable(expectedBddTable);
            foreach (DataRow dr in dt.Rows)
            {
                foreach (DataRow expectedDR in bddExpectedDataTable.Rows)
                {
                    string attributeName = (string)expectedDR["Attribute"];
                    string dataType = (string)expectedDR["DataType"];
                    var miniValue = expectedDR["MiniValue"];
                    var maxValue = expectedDR["MaxValue"];
                    var dataLengthValue = Int32.Parse((string)expectedDR["DataLength"]);

                    //Console.WriteLine("I am about to test this attribute: " + attributeName);
                   // Console.WriteLine("This attribute : " + dr[attributeName]);
                   // Console.WriteLine("The length is : " + dr[attributeName].ToString().Length);
                    Assert.IsTrue(dr[attributeName].ToString().Length <= dataLengthValue,$"This attribute failed:{attributeName},with value:{dr[attributeName]} because of length:{dr[attributeName].ToString().Length}");
                    //int max = Convert.ToInt32(dt.AsEnumerable().Max(row => row[attributeName]));


                    // Console.WriteLine("This osid is: {0} ,The versiondate is: {1}, The versionavailablefromdate is: {2}, The versionavailabletodate is: {3}",
                    // dr["osid"], dr["versiondate"], dr["versionavailablefromdate"], dr["versionavailabletodate"]);
                    ////osid,versiondate,versionavailablefromdate,versionavailabletodate,changetype,geometry,geometry_length,theme,description,boundarytype
                    //Console.WriteLine("This is osid length: " + dr["versiondate"].ToString().Length);
                    //Console.WriteLine("This is osid type: " + dr["versiondate"].GetType());
                    //Console.WriteLine("This is versionavailablefromdate length: " + dr["versionavailablefromdate"].ToString().Length);
                    //Console.WriteLine("This is versionavailablefromdate type: " + dr["versionavailablefromdate"].GetType());
                    //Console.WriteLine("This is versionavailabletodate length: " + dr["versionavailabletodate"].ToString().Length);
                    //Console.WriteLine("This is versionavailabletodate type: " + dr["versionavailabletodate"].GetType());
                    //Console.WriteLine("This is changetype length: " + dr["changetype"].ToString().Length);
                    //Console.WriteLine("This is changetype type: " + dr["changetype"].GetType());
                    //Console.WriteLine("This is geometry length: " + dr["geometry"].ToString().Length);
                    //Console.WriteLine("This is geometry type: " + dr["geometry"].GetType());
                    //Console.WriteLine("This is geometry_length length: " + dr["geometry_length"].ToString().Length);
                    //Console.WriteLine("This is geometry_length type: " + dr["geometry_length"].GetType());
                    //Console.WriteLine("This is theme length: " + dr["theme"].ToString().Length);
                    //Console.WriteLine("This is theme type: " + dr["theme"].GetType());
                    //Console.WriteLine("This is description length: " + dr["description"].ToString().Length);
                    //Console.WriteLine("This is description type: " + dr["description"].GetType());
                    //Console.WriteLine("This is boundarytype length: " + dr["boundarytype"].ToString().Length);
                    //Console.WriteLine("This is boundarytype type: " + dr["boundarytype"].GetType());
                }
            }
        }
        
        private string FilePathForDownloadedFiles(string scenarioNumber, string folderDate)
        {
            string strFilePath = $"{Settings.DownloadedDataFiles}\\{folderDate}\\{scenarioNumber}";
            return strFilePath;
        }
    }
}
