﻿using ApplicationUnderTest.Pages;
using NUnit.Framework;
using OSBaseAutoFramework.Helpers;
using OSDataHubUIProject.Data.JsonDataTemplate;
using OSDataHubUIProject.Pages;
using SpecFlowProjectNUnit.Pages;

namespace OSDataHubUIProject.StepDefinitions
{
    [Binding]
    public sealed class CreateANewRecipeSteps 
    {
        private readonly ScenarioContext _scenarioContext;
        private readonly IDataHubUIHomePage _dataHubUIHomePage;
        private readonly IDataHubUILoginPage _dataHubUILoginPage;
        private readonly ICreateANewRecipePage _createANewRecipePage;
        private readonly IAddDataPackagePage _addDataPackagePage;

        public CreateANewRecipeSteps(ScenarioContext scenarioContext, ICreateANewRecipePage createANewRecipePage, IDataHubUIHomePage dataHubUIHomePage)
        {
            _scenarioContext = scenarioContext;
            _createANewRecipePage = createANewRecipePage;
            _dataHubUIHomePage = dataHubUIHomePage;
        }

        [StepDefinition(@"I created a new recipe with the ""([^""]*)"" name and ""([^""]*)"" description for the selected ""([^""]*)"" theme")]
        public void WhenICreatedANewRecipeWithTheNameAndDescriptionForTheSelectedTheme(string recipeName, string recipeDescription, string themeName)
        {
            OpenedCreateARecipe();
            IEnterANameForTheRecipe(recipeName);
            IEnterADescriptionForTheRecipe(recipeDescription);
            ISelectedTheThemeForTheRecipe(themeName);
            IClickOnTheCreateRecipeButton();
            IVerifiedTheRecipeIsCreated();
            TheSelected(themeName);
        }


        [StepDefinition(@"I created a new recipe with ""([^""]*)"" and ""([^""]*)"" for selected ""([^""]*)"" and ""([^""]*)""")]
        public void GivenICreatedANewRecipeWithAndForSelectedAnd(string recipeName, string recipeDescription, string themeName, string features)
        {
            OpenedCreateARecipe();
            IEnterANameForTheRecipe(recipeName);
            IEnterADescriptionForTheRecipe(recipeDescription);
            ISelectedTheThemeForTheRecipe(themeName);
            IClickOnTheCreateRecipeButton();
            IVerifiedTheRecipeIsCreated();
            TheSelected(themeName);
        }

        [StepDefinition(@"I created a new recipe with above filters for ""([^""]*)"" name and ""([^""]*)"" description for the selected ""([^""]*)"" theme")]
        public void WhenICreatedANewRecipeWithAboveFiltersForNameAndDescriptionForTheSelectedTheme(string recipeName, string recipeDescription, string themeName)
        {
            IEnterANameForTheRecipe(recipeName);
            IEnterADescriptionForTheRecipe(recipeDescription);
            IClickOnTheCreateRecipeButton();
            IVerifiedTheRecipeIsCreated();
            TheSelected(themeName);
        }

        [StepDefinition(@"I click on the Add data package button for newly created recipe")]
        public void WhenIClickOnTheAddDataPackageButtonForNewlyCreatedRecipe()
        {
            _createANewRecipePage.ClickAddDataPackage();
        }


        [StepDefinition(@"I enter a ""([^""]*)"" name for the recipe")]
        public void IEnterANameForTheRecipe(string recipeName)
        {
            _createANewRecipePage.EnterRecipeName(recipeName);
        }

        [StepDefinition(@"I enter a ""([^""]*)"" description for the recipe")]
        public void IEnterADescriptionForTheRecipe(string recipeDescription)
        {
            _createANewRecipePage.EnterDescription(recipeDescription);
        }

        [StepDefinition(@"I selected the ""([^""]*)"" theme for the recipe")]
        public void ISelectedTheThemeForTheRecipe(string themeName)
        {
            FileRepository.ThemeName = themeName.ToString();
            _createANewRecipePage.SelectThemeOrFeature(themeName);
        }

        [StepDefinition(@"I click on the Create recipe button")]
        public void IClickOnTheCreateRecipeButton()
        {
            _createANewRecipePage.CreateANewRecipe();
        }

        [StepDefinition(@"I verified the recipe is created")]
        public void IVerifiedTheRecipeIsCreated()
        {
            Assert.IsTrue(_createANewRecipePage.VerifyRecipeCreated());
        }

        [StepDefinition(@"The selected ""([^""]*)""")]
        public void TheSelected(string themeName)
        {
            Assert.AreEqual(_createANewRecipePage.VerifySelectedTheme(),themeName);
        }

        [StepDefinition(@"I verify the recipe is created with selected ""([^""]*)"" theme")]
        public void ThenIVerifyTheRecipeIsCreatedWithSelectedTheme(string themeName)
        {
            Assert.IsTrue(_createANewRecipePage.VerifyRecipeCreated());
            Assert.AreEqual(_createANewRecipePage.VerifySelectedTheme(), themeName);
        }

        [StepDefinition(@"I click create a new recipe")]
        public void OpenedCreateARecipe()
        {
            _dataHubUIHomePage.ClickLink("Download");
            _dataHubUIHomePage.ClickLink("Create a new recipe");
        }

        [StepDefinition(@"I should be able to tick")]
        public void WhenIShouldBeAbleToTick(Table themeSelectionTable)
        {
            foreach (string themeName in Utilities.ConvertTableToList(themeSelectionTable))
            {
                _createANewRecipePage.SelectThemeOrFeature(themeName);
            }
        }

        [StepDefinition(@"I apply filter for ""([^""]*)"" feature under ""([^""]*)"" collections under ""([^""]*)"" theme")]
        public void WhenIApplyFilterForFeatureUnderCollectionsUnderTheme(string featureName, string collectionName, string themeName)
        {
            _createANewRecipePage.ExpandThemeOrFeature(themeName);
            _createANewRecipePage.ExpandThemeOrFeature(collectionName);
            _createANewRecipePage.SelectThemeOrFeature(featureName);
            _createANewRecipePage.ClickApplyFilter(featureName);
        }

        [StepDefinition(@"I click ""([^""]*)"" option")]
        public void WhenIClickOption(string filterAddRuleOrAddGroup)
        {
            _createANewRecipePage.ClickAddRuleOrGroup(filterAddRuleOrAddGroup);
        }

        [StepDefinition(@"I select the ""([^""]*)"" and ""([^""]*)"" with ""([^""]*)""")]
        public void WhenISelectTheAndWith(string attributeName, string operatorValue, string attributeValue)
        {
            _createANewRecipePage.SelectAttribute(attributeName);
            _createANewRecipePage.SelectOperator(operatorValue);
            _createANewRecipePage.EnterAttributeValue(attributeValue);
            _createANewRecipePage.ClickApplyFilter();
        }
    }
}
