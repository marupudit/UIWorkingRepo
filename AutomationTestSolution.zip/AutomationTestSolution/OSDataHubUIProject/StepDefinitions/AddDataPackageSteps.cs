﻿using ApplicationUnderTest.Pages;
using NUnit.Framework;
using OSBaseAutoFramework.Helpers;
using OSDataHubUIProject.Data.CSVDataFileTemplate;
using OSDataHubUIProject.Data.JsonDataTemplate;
using OSDataHubUIProject.Pages;
using SpecFlowProjectNUnit.Pages;

namespace OSDataHubUIProject.StepDefinitions
{
    [Binding]
    public sealed class AddDataPackageSteps 
    {
        private readonly ScenarioContext _scenarioContext;
        private readonly IDataHubUIHomePage _dataHubUIHomePage;
        private readonly IDataHubUILoginPage _dataHubUILoginPage;
        private readonly ICreateANewRecipePage _createANewRecipePage;
        private readonly IAddDataPackagePage _addDataPackagePage;

        public AddDataPackageSteps(ScenarioContext scenarioContext, ICreateANewRecipePage createANewRecipePage, IAddDataPackagePage addDataPackagePage)
        {
            _scenarioContext = scenarioContext;
            _createANewRecipePage = createANewRecipePage;
            _addDataPackagePage = addDataPackagePage;
        }

        [StepDefinition(@"I added a new ""([^""]*)"" data package with ""([^""]*)"" area ""([^""]*)"" one-off updates for the newly created recipe in the ""([^""]*)"" file format with the supply date ""([^""]*)""")]
        public void WhenIAddedANewDataPackageWithAreaOne_OffUpdatesForTheNewlyCreatedRecipeInTheFileFormatWithTheSupplyDate(string dataPackageName, string chooseArea, string oneOffStatusValue, string fileFormat, string initialSupplyDate)
        {
            _createANewRecipePage.ClickAddDataPackage();
            _addDataPackagePage.EnterDataPackageName(dataPackageName);
            _addDataPackagePage.SelectAreaOfMapScope(chooseArea);
            _addDataPackagePage.SelectTheFileFormat(fileFormat);
            _addDataPackagePage.TickOneOffCheckBox(oneOffStatusValue);
            _addDataPackagePage.EnterInitialSupplyDate(initialSupplyDate);
            _addDataPackagePage.ClickCreateDataPackage();
            FileRepository.FileFormat = fileFormat.ToString();
            DataPackageInformation.AddRecordToOSDataPackageInfoFile(FileRepository.ScenarioNumber, FileRepository.RecipeName, FileRepository.DataPackageName, FileRepository.ThemeName, FileRepository.AreaCoverage,FileRepository.FileFormat, Utilities.CurrentSystemDateWithHr());
        }


        [StepDefinition(@"I enter a ""([^""]*)"" package name")]
        public void WhenIEnterAPackageName(string dataPackageName)
        {

            _addDataPackagePage.EnterDataPackageName(dataPackageName);
        }

        [StepDefinition(@"I choose area ""([^""]*)""")]
        public void WhenIChooseArea(string chooseArea)
        {
            _addDataPackagePage.SelectAreaOfMapScope(chooseArea);
        }

        [StepDefinition(@"I selected the ""([^""]*)"" file format")]
        public void WhenISelectedTheFileFormat(string fileFormat)
        {
            _addDataPackagePage.SelectTheFileFormat(fileFormat);
        }

        [StepDefinition(@"I ""([^""]*)"" the one-off checkbox")]
        public void WhenITheOne_OffCheckbox(string oneOffStatusValue)
        {
            _addDataPackagePage.TickOneOffCheckBox(oneOffStatusValue);
        }


        [StepDefinition(@"I supplied the ""([^""]*)""")]
        public void WhenISuppliedThe(string initialSupplyDate)
        {
            _addDataPackagePage.EnterInitialSupplyDate(initialSupplyDate);
        }

        [StepDefinition(@"I click on the Create Data Package button")]
        public void WhenIClickOnTheCreateDataPackageButton()
        {
            _addDataPackagePage.ClickCreateDataPackage();
        }

        [StepDefinition(@"I verified the confirmation message ""([^""]*)""")]
        public void ThenIVerifiedTheConfirmationMessage(string confrimationMessage)
        {
            Assert.IsTrue(_addDataPackagePage.ConfirmationThankYou());
            Assert.IsTrue(_addDataPackagePage.ConfirmationText());
            _addDataPackagePage.ClickDataPackageLinkInDescription();
        }

        [StepDefinition(@"I check ""([^""]*)"" status is displayed for newly created data package")]
        public void ThenICheckStatusIsDisplayedForNewlyCreatedDataPackage(string expectedStatus)
        {
            _addDataPackagePage.SearchDataPackage();
            Assert.AreEqual(_addDataPackagePage.GetStatusOfDataPackage(), expectedStatus);
        }

        [StepDefinition(@"I search for ""([^""]*)"" under the packages")]
        public void ISearchForUnderThePackages(string dataPackageName)
        {
            _addDataPackagePage.SearchDataPackage(dataPackageName);
        }

        [StepDefinition(@"I click on the Download data link")]
        public void WhenIClickOnTheDownloadDataLink()
        {
            _addDataPackagePage.DownloadDataFile();
        }

        [StepDefinition(@"I click on the ""([^""]*)"" on data package")]
        public void WhenIClickOnTheOnDataPackage(string dataPackageName)
        {
            _addDataPackagePage.ClickDataPackage(dataPackageName);
        }

        [StepDefinition(@"I click on the ""([^""]*)"" link")]
        public void WhenIClickOnTheLink(string linkName)
        {
            _addDataPackagePage.ClickLink(linkName);                       
        }

        [StepDefinition(@"I click on the Delete package confirmation")]
        public void ThenIClickOnTheDeletePackageConfirmation()
        {
            _addDataPackagePage.ClickDeletePackageConfirmation();
        }


        [StepDefinition(@"I verify the ""([^""]*)"" confirmation displayed")]
        public void ThenIVerifyTheConfirmationDisplayed(string confirmationText)
        {
            Assert.AreEqual(_addDataPackagePage.VerifyConfirmationText(),confirmationText);
        }
        
    }
}
