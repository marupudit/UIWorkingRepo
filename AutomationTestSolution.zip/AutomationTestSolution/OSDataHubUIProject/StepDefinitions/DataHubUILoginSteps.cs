using ApplicationUnderTest.Pages;
using NUnit.Framework;
using OSDataHubUIProject.Data;
using OSDataHubUIProject.Data.JsonDataTemplate;
using SpecFlowProjectNUnit.Pages;

namespace AutoSpecflowTests.StepDefinitions
{
    [Binding]
    public sealed class DataHubUILoginSteps
    {
        private readonly ScenarioContext _scenarioContext;
        private readonly IDataHubUIHomePage _dataHubUIHomePage;
        private readonly IDataHubUILoginPage _dataHubUILoginPage;

        public DataHubUILoginSteps(ScenarioContext scenarioContext, IDataHubUIHomePage dataHubUIHomePage, IDataHubUILoginPage dataHubUILoginPage)
        {
            _scenarioContext = scenarioContext;
            _dataHubUIHomePage = dataHubUIHomePage;
            _dataHubUILoginPage = dataHubUILoginPage;
        }

        [StepDefinition(@"I log in to the OS Data Hub portal as a premium plan registered user")]
        public void GivenILogInToTheOSDataHubPortalAsAPremiumPlanRegisteredUser()
        {
            SetScenarioNumber();           
            WhenIClickLogInButton();
            GivenILoginInWithValidRegisteredUserCredentialsUnderThePremiumPlan();
        }        

        [StepDefinition(@"I click logIn button")]
        public void WhenIClickLogInButton()
        {
            _dataHubUIHomePage.ClickLogin();
        }

        [StepDefinition(@"I click on the ""([^""]*)"" button on the homepage")]
        public void WhenIClickOnTheButtonOnTheHomepage(string linkDesc)
        {
            _dataHubUIHomePage.ClickLink(linkDesc);
        }

        [StepDefinition(@"I login in with valid registered user credentials under the premium plan")]
        public void GivenILoginInWithValidRegisteredUserCredentialsUnderThePremiumPlan()
        {
            WhenIEnterValidLoginCredentials();
            ThenISuccessfullyLoginToApplication();
        }

        [StepDefinition(@"I enter valid login credentials")]
        public void WhenIEnterValidLoginCredentials()
        {
            JsonDataConfiguration _jsonDataConfiguration = new JsonDataConfiguration();
            var loginDetails = _jsonDataConfiguration.ConfigureJsonData<LoginCredentails>("LoginCredentails");
            _dataHubUILoginPage.EnterLoginCredentails(loginDetails.UserName, loginDetails.Password);
        }

        [StepDefinition(@"I enter invalid (.*) login credentials")]
        public void WhenIEnterInvalidLoginCredentials(string credentail)
        {
            JsonDataConfiguration _jsonDataConfiguration = new JsonDataConfiguration();
            var loginDetails = _jsonDataConfiguration.ConfigureJsonData<LoginCredentails>("LoginCredentails");
            if (credentail.ToLower() == "email")
            {
                _dataHubUILoginPage.EnterLoginCredentails(loginDetails.InvalidUserName, loginDetails.Password);
            }
            else if (credentail.ToLower() == "password")
            {
                _dataHubUILoginPage.EnterLoginCredentails(loginDetails.UserName, loginDetails.InvalidPassword);
            }
        }


        [StepDefinition(@"I successfully login to application")]
        public void ThenISuccessfullyLoginToApplication()
        {
            JsonDataConfiguration _jsonDataConfiguration = new JsonDataConfiguration();
            var loginDetails = _jsonDataConfiguration.ConfigureJsonData<LoginCredentails>("LoginCredentails");
            _dataHubUILoginPage.SuccessfulLogin();
            Assert.AreEqual(_dataHubUIHomePage.VerifyLoginSuccessful(), loginDetails.User, "Failed to Login into the application");
        }

        [StepDefinition(@"I click ""(.*)"" link on login page")]
        public void WhenIClickLinkOnLoginPage(string linkText)
        {
            _dataHubUILoginPage.ClickLink(linkText);
        }

        [StepDefinition(@"I expect to see the ""(.*)"" page")]
        public void ThenIExpectToSeeThePage(string expectedPageTitle)
        {
            Assert.AreEqual(expectedPageTitle, _dataHubUILoginPage.GetPageTitle(), "Expected page is not displayed");
        }

        [StepDefinition(@"I open OS Data Hub portal homepage")]
        public void GivenTheOSDataHubPortalHomepage()
        {
            //Handling as part of start-up
        }

        private List<string> ConvertTableToList(Table inputTable)
        {
            List<string> convertedList = new List<string>();
            foreach (var tablerow in inputTable.Rows)
            {
                string text = tablerow["Options"];
                convertedList.Add(tablerow["Options"]);
            }
            return convertedList;
        }

        private void SetScenarioNumber()
        {
            var stepType = _scenarioContext.ScenarioInfo.Title.Trim().ToString();
            String[] scenarioTitle = stepType.Split(":");
            FileRepository.ScenarioNumber = scenarioTitle[0];
        }
    }
}