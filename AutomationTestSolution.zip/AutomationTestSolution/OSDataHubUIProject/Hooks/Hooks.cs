﻿using NUnit.Framework;
using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using AventStack.ExtentReports.Gherkin.Model;
using CsvHelper;
using System.Globalization;
using OSDataHubUIProject.Data.CSVDataFileTemplate;
using Serilog;
using TestFramework.Driver;
using TestFramework.Config;
using OSBaseAutoFramework.Helpers;
using PGSAEndToEndBaseProject.Config;

//Same parallel
[assembly: Parallelizable(ParallelScope.Fixtures)]

namespace OSDataHubUIProject.Hooks
{
    [Binding]
    public class Hooks
    {
        private readonly FeatureContext _featureContext;
        private readonly ScenarioContext _scenarioContext;
        private ExtentTest _currentScenarioName;
        private readonly IDriverWait _driver;

        public Hooks(FeatureContext featureContext, ScenarioContext scenarioContext, IDriverWait driver)
        {
            _featureContext = featureContext;
            _scenarioContext = scenarioContext;
            _driver = driver;
        }
        //Creating the private parameters that holds performance/execution time metrics       
        private long _start { get; set; }
        private long _end { get; set; }
        private static long _startTotal { get; set; }
        private static long _endTotal { get; set; }
        private static long _totalDuration { get; set; }

        private static ExtentTest featureName;
        private static ExtentReports extent;
        private static ExtentKlovReporter klov;


        [BeforeStep]
        public void BeforeStep()
        {
            //Capturing this metrics to calculate the overall duration for each step
            _start = DateTimeOffset.Now.ToUnixTimeMilliseconds();
        }

        [AfterStep]
        public void AfterStep()
        {
            _end = DateTimeOffset.Now.ToUnixTimeMilliseconds();
            Console.WriteLine(_end - _start + " : Milliseconds took to load this step : " + _scenarioContext.StepContext.StepInfo.Text);

            var stepType = _scenarioContext.StepContext.StepInfo.StepDefinitionType.ToString();
            var stepDetails = _scenarioContext.StepContext.StepInfo.Text.ToString();

            if (_scenarioContext.TestError == null)
            {
                if (stepType == "Given")
                    _currentScenarioName.CreateNode<Given>(_scenarioContext.StepContext.StepInfo.Text);
                else if (stepType == "When")
                    _currentScenarioName.CreateNode<When>(_scenarioContext.StepContext.StepInfo.Text);
                else if (stepType == "Then")
                    _currentScenarioName.CreateNode<Then>(_scenarioContext.StepContext.StepInfo.Text);
                else if (stepType == "And")
                    _currentScenarioName.CreateNode<And>(_scenarioContext.StepContext.StepInfo.Text);
                Log.Information("Executed this step :" + stepDetails);
            }
            else if (_scenarioContext.TestError != null)
            {
                //screenshot in the Base64 format
                var mediaEntity = _driver.CaptureScreenshotAndReturnModel(_scenarioContext.ScenarioInfo.Title.Trim());

                if (stepType == "Given")
                    _currentScenarioName.CreateNode<Given>(_scenarioContext.StepContext.StepInfo.Text).Fail(_scenarioContext.TestError.Message, mediaEntity);
                else if (stepType == "When")
                    _currentScenarioName.CreateNode<When>(_scenarioContext.StepContext.StepInfo.Text).Fail(_scenarioContext.TestError.Message, mediaEntity);
                else if (stepType == "Then")
                    _currentScenarioName.CreateNode<Then>(_scenarioContext.StepContext.StepInfo.Text).Fail(_scenarioContext.TestError.Message, mediaEntity);
                Log.Error("Error in this step: " + stepDetails);
            }
            else if (_scenarioContext.ScenarioExecutionStatus.ToString() == "StepDefinitionPending")
            {
                if (stepType == "Given")
                    _currentScenarioName.CreateNode<Given>(ScenarioStepContext.Current.StepInfo.Text).Skip("Step Definition Pending");
                else if (stepType == "When")
                    _currentScenarioName.CreateNode<When>(ScenarioStepContext.Current.StepInfo.Text).Skip("Step Definition Pending");
                else if (stepType == "Then")
                    _currentScenarioName.CreateNode<Then>(ScenarioStepContext.Current.StepInfo.Text).Skip("Step Definition Pending");
                Log.Warning("This step is not implemented: " + stepDetails);
            }
        }

        [BeforeTestRun]
        public static void TestInitalize()
        {
            //Reading App settings and setting pre-requiste configurations
            var configReader = new ConfigReader();
            configReader.SetFrameworkSettings();
            // Seri logs to caputure the logging
            Log.Logger = new LoggerConfiguration()
              .WriteTo.Console()
              .WriteTo.File(Settings.SeriInfoLogFileLocation.ToString(),
                restrictedToMinimumLevel: Serilog.Events.LogEventLevel.Information,
                rollingInterval: RollingInterval.Day)
              .WriteTo.File(Settings.SeriErrorLogFileLocation.ToString(),
                restrictedToMinimumLevel: Serilog.Events.LogEventLevel.Warning,
                rollingInterval: RollingInterval.Day)
              .CreateLogger();

            //Extent report - HTMl Reporter
            var path = Path.Combine(Settings.ExtentReportPath.ToString());
            //Initialize Extent report before test starts
            var htmlReporter = new ExtentHtmlReporter(path);
            htmlReporter.Config.Theme = AventStack.ExtentReports.Reporter.Configuration.Theme.Dark;
            //Attach report to reporter
            extent = new AventStack.ExtentReports.ExtentReports();
            klov = new ExtentKlovReporter();
            extent.AttachReporter(htmlReporter);

            //Creating CSV file to caputure the data files information
            using (var streamWriter = new StreamWriter(Settings.DatapackageInfoCsv.ToString(), false))
            {
                using (var csvWriter = new CsvWriter(streamWriter, CultureInfo.InvariantCulture))
                {
                    var dataPackageInfo = DataPackageInformation.GetDataPackage();
                    //csvWriter.Context.RegisterClassMap<DataPackageInformationClassMap>();
                    csvWriter.WriteRecords(dataPackageInfo);
                }
            }
        }

        [AfterTestRun]
        public static void TearDownReport()
        {
            //Flush report once test completes
            extent.Flush();
            //Creating back-up file for data validation
            string csvBackUpFilePath = Path.Combine(Settings.DatapackageInfoRoot, $"OSDataPackageInfo-{Utilities.CurrentSystemDate()}.csv");
            File.Copy(Settings.DatapackageInfoCsv.ToString(), csvBackUpFilePath, true);
            //Creating data file in Json format
            var csvFormatData = CSVToJsonConverter.ConvertCsvFileToJsonObject(Settings.DatapackageInfoCsv.ToString());
            File.WriteAllText(@Settings.DatapackageInfoJson.ToString(), csvFormatData);
            //Close and flush the logging
            Log.CloseAndFlush();
        }

        [BeforeScenario]
        public void BeforeScenario()
        {
            //Get feature Name
            featureName = extent.CreateTest<Feature>(_featureContext.FeatureInfo.Title);
            //Create dynamic scenario name
            _currentScenarioName = featureName.CreateNode<Scenario>(_scenarioContext.ScenarioInfo.Title);
        }

        [AfterScenario]
        public void AfterScenario()
        {
            //After each test scenario closing the browser and quiting
            _driver.DriverInstance().Close();
            _driver.DriverInstance().Quit();
        }

        [BeforeFeature]
        public static void BeforeFeature()
        {
            //Capturing the timings for performance metrics
            _startTotal = DateTimeOffset.Now.ToUnixTimeMilliseconds();
        }

        [AfterFeature]
        public static void AfterFeature()
        {
            //Capturing the timings for performance metrics
            _endTotal = DateTimeOffset.Now.ToUnixTimeMilliseconds();
            _totalDuration = (_endTotal - _startTotal) / 1000;
            Console.WriteLine(_totalDuration + " : Seconds took to test this scenario");
            //Commenting for now, Once we run the baseline test execution time and if its around 60 seconds, so we can benchmarking the performance to 75 seconds [25% contingency on top of baseline] 
            //and failing test if the overall test execution time breaches
            //Assert.LessOrEqual(_totalDuration, 75);
        }
    }
}
