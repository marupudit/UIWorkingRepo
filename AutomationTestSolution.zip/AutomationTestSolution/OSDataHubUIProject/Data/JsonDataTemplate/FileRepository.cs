﻿namespace OSDataHubUIProject.Data.JsonDataTemplate
{
    public class FileRepository
    {
        public static string ScenarioNumber { get; set; }
        public static string RecipeName { get; set; }
        public static string DataPackageName { get; set; }
        public static string ThemeName { get; set; }
        public static string AreaCoverage { get; set; }
        public static string FileFormat { get; set;}

    }
}