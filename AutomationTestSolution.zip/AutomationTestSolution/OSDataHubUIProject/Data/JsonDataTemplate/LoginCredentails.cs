﻿namespace OSDataHubUIProject.Data.JsonDataTemplate
{
    public class LoginCredentails
    {
        public string User { get; set; }    
        public string UserName { get; set; }
        public string Password { get; set; }
        public string InvalidUserName { get; set; }
        public string InvalidPassword { get; set; }
    }
}
