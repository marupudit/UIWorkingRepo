﻿using OSBaseAutoFramework.Helpers;
using CsvHelper.Configuration;

namespace OSDataHubUIProject.Data.CSVDataFileTemplate
{
    //public class DataPackageInformationClassMap:ClassMap<DataPackageInformation>
    //{
    //    public DataPackageInformationClassMap() 
    //    {
    //        Map(d => d.ScenarioName).Name("ScenarioName");
    //        Map(d => d.RecipeName).Name("RecipeName");
    //        Map(d => d.DataPackageName).Name("DataPackageName");
    //        Map(d => d.CreationDateAndHr).Name("CreationDateAndHr").TypeConverterOption.Format("s");
    //    }
    //}

    public class DataPackageInformation
    {
        public string ScenarioName { get; set; }
        public string RecipeName { get; set; }
        public string DataPackageName { get; set; }        
        public string ThemeName { get; set; }
        public string AreaCoverage { get; set; }
        public string FileFormat { get; set; }
        public string CreationDateAndHr { get; set; }


        public static List<DataPackageInformation> GetDataPackage()
        {
            return new List<DataPackageInformation>
            {
                new DataPackageInformation()
                {
                    ScenarioName = "AC00",
                    RecipeName = " ",
                    DataPackageName = " ",
                    ThemeName = " ",
                    AreaCoverage = " ",
                    FileFormat = " ",
                    CreationDateAndHr = Utilities.CurrentSystemDateWithHr()
                }
            };
        }

        public static void AddRecordToOSDataPackageInfoFile(string scenarioName,string recipeName,string dataPackageName,string themeName,string areaCoverage,string fileFormat, string creationDateAndHr)
        {
            var csvFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory + "\\..\\..\\..\\", $"OSDataPackageInfo.csv");
            try
            {
                using(System.IO.StreamWriter file = new System.IO.StreamWriter(@csvFilePath, true))
                {
                    file.WriteLine(scenarioName + "," + recipeName + "," + dataPackageName + ","+ themeName + ","+ areaCoverage + "," +fileFormat + "," + creationDateAndHr);
                }
            }
            catch(Exception ex) 
            {
                throw new ApplicationException("Unable to add record because :", ex);
            }
        }
    }
}
