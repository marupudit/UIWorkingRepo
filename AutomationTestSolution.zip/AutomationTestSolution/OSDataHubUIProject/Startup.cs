﻿using ApplicationUnderTest.Pages;
using Microsoft.Extensions.DependencyInjection;
using OSDataHubUIProject.Pages;
using SolidToken.SpecFlow.DependencyInjection;
using SpecFlowProjectNUnit.Pages;
using TestFramework.Config;
using TestFramework.Driver;

namespace AutoSpecflowTests
{
    public class Startup
    {
        [ScenarioDependencies]
        public static IServiceCollection CreateServices()
        {
            var services = new ServiceCollection();
            services
                .AddSingleton(ConfigReader.ReadConfig())
                .AddScoped<IDriverFixture, DriverFixture>()
                .AddScoped<IDriverWait, DriverWait>()
                .AddScoped<IAddDataPackagePage, AddDataPackagePage>()
                .AddScoped<ICreateANewRecipePage, CreateANewRecipePage>()
                .AddScoped<IDataHubUIHomePage,DataHubUIHomePage>()
                .AddScoped<IDataHubUILoginPage, DataHubUILoginPage>()
                .AddScoped<IDownloadDataFilesPage,DownloadDataFilesPage>();
            return services;
        } 
    }
}
