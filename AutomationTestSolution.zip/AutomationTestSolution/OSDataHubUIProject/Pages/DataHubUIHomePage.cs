﻿using OpenQA.Selenium;
using SpecFlowProjectNUnit.Pages;
using TestFramework.Driver;
using TestFramework.Extensions;

namespace ApplicationUnderTest.Pages
{
    public interface IDataHubUIHomePage
    {
        void AcceptCookies();
        void ClickLink(string linkDesc);
        void ClickLogin();
        void ClickSign();
        string VerifyLoginSuccessful();
    }

    public class DataHubUIHomePage : IDataHubUIHomePage
    {
        private readonly IDriverWait _driver;
        public DataHubUIHomePage(IDriverWait driver)
        {
            _driver = driver;
        }
        /// <summary>
        /// Defining the page objects/ elements that I need to interact on webpage
        /// </summary>
        /// 
        private IWebElement btnSignIn => _driver.FindElement(By.XPath("//span[normalize-space()='Sign in']"));
        private IWebElement _btnAcceptCookies => _driver.FindElement(By.Id("ccc-notify-accept"));
        private IWebElement _txtUserDetails => _driver.FindElement(By.XPath("//span[@class='MuiButton-label jss21']"));

        /// <summary>
        /// Defining the actions that needs to perform on home page webpage
        /// </summary>
        /// 

        public void ClickLogin()
        {
            AcceptCookies();            
            ClickSign();
        }

        public string VerifyLoginSuccessful()
        {
            _txtUserDetails.WaitForElementIsVisible(TimeoutInSeconds.DefaultTimeout);
            return _txtUserDetails.Text;
        }

        public void ClickLink(string linkDesc)
        {
            IWebElement _lnkDynamicElement = _driver.FindElement(By.XPath($"//span[normalize-space()='{linkDesc}']"));
            _lnkDynamicElement.Click();
        }

        public void ClickSign()
        {
            _driver.DriverInstance().ClickAndWait(btnSignIn, WaitTime.VeryLongWaitTime);
        } 

        public void AcceptCookies()
        {
            _btnAcceptCookies.Click();
        }
    }
}
