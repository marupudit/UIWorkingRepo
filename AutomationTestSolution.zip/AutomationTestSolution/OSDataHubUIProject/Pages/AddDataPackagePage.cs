﻿using OpenQA.Selenium;
using OSDataHubUIProject.Data.JsonDataTemplate;
using OSBaseAutoFramework.Helpers;
using TestFramework.Driver;
using TestFramework.Extensions;

namespace OSDataHubUIProject.Pages
{
    public interface IAddDataPackagePage
    {
        void ClickCreateDataPackage();
        void ClickDataPackage(string packageName = "");
        void ClickDataPackageLinkInDescription();
        void ClickDeletePackageConfirmation();
        void ClickLink(string linkName);
        void ClickOnDataPackages();
        bool ConfirmationText();
        bool ConfirmationThankYou();
        void DownloadDataFile();
        void EnterDataPackageName(string dataPackageName);
        void EnterInitialSupplyDate(string supplyDate);
        string GetStatusOfDataPackage();
        void SearchDataPackage(string packageName = "");
        void SelectAreaOfMapScope(string chooseArea);
        void SelectTheFileFormat(string fileFormat);
        void TickOneOffCheckBox(string oneOffStatusValue);
        string VerifyConfirmationText();
    }

    public class AddDataPackagePage : IAddDataPackagePage
    {
        private readonly IDriverWait _driver;
        public AddDataPackagePage(IDriverWait driver)
        {
            _driver = driver;
        }
        /// <summary>
        /// Defining the page objects/ elements that I need to interact on webpage
        /// </summary>
        /// 

        private IWebElement _txtEnterDataPackageName => _driver.FindElement(By.Id("packageName"));

        private IWebElement _rdoAllOfBritian => _driver.FindElement(By.XPath("//input[@value='GB']"));

        private IWebElement _rdoDrawAPolygon => _driver.FindElement(By.XPath("//input[@value='Polygon']"));

        private IWebElement _sltFileFormat => _driver.FindElement(By.XPath("//div[normalize-space()='Select file format']"));

        private IWebElement _chkTickOneOffSnapshot => _driver.FindElement(By.XPath("//input[@aria-label='I want a one-off snapshot of a date in the past']"));

        private IWebElement _txtEnterInitialSupplyDate => _driver.FindElement(By.XPath("//input[@placeholder='dd/mm/yyyy']"));

        private IWebElement _btnCreateDataPackage => _driver.FindElement(By.XPath("//span[normalize-space()='Create data package']"));

        private IWebElement _txtConfirmationThankYou => _driver.FindElement(By.XPath("//p[normalize-space()='Thank you.']"));

        private IWebElement _txtConfirmationText => _driver.FindElement(By.XPath("//p[contains(text(),'We’re creating your data package. We’ll email you ')]"));

        private IWebElement _lnkDataPackages => _driver.FindElement(By.XPath("//span[normalize-space()='Data packages']"));

        private IWebElement _lnkDataPackagesInDescription => _driver.FindElement(By.XPath("//a[normalize-space()='data packages']"));

        private IWebElement _txtSearchDataPackageName => _driver.FindElement(By.Id("search"));

        private IWebElement _txtStatus => _driver.FindElement(By.XPath("//td[normalize-space()='Available soon']"));

        private IWebElement _txtDeletePackageConfirmation => _driver.FindElement(By.XPath("//p[normalize-space()='You have successfully deleted your data package.']"));

        private IWebElement _btnConfirmationDeletePackage => _driver.FindElement(By.XPath("//span[normalize-space()='Delete package']"));

        public void EnterDataPackageName(string dataPackageName)
        {
            dataPackageName = dataPackageName + Utilities.CurrentSystemDate();
            FileRepository.DataPackageName = dataPackageName.ToString();
            _txtEnterDataPackageName.ClearAndEnterText(dataPackageName);
        }

        public void SelectAreaOfMapScope(string chooseArea)
        {
            FileRepository.AreaCoverage = chooseArea.ToString();
            if (chooseArea == "AllOfBritian")
            {
                _rdoAllOfBritian.Click();
            }
            else if (chooseArea == "DrawAPolygon")
            {
                _rdoDrawAPolygon.Click();
            }
        }

        public void SelectTheFileFormat(string fileFormat)
        {
            _sltFileFormat.Click();
            _driver.FindElement(By.XPath($"//ul[@aria-labelledby='format_label']//li[@data-value='{fileFormat}']")).Click();
        }

        public void TickOneOffCheckBox(string oneOffStatusValue)
        {
            if (oneOffStatusValue == "Enabled")
            {
                _chkTickOneOffSnapshot.Click();
            }
        }

        public void EnterInitialSupplyDate(string supplyDate)
        {
            _txtEnterInitialSupplyDate.ClearAndEnterText(supplyDate);
        }

        public void ClickCreateDataPackage()
        {
            _btnCreateDataPackage.Click();
        }

        public bool ConfirmationThankYou()
        {
            return _txtConfirmationThankYou.Displayed;
        }

        public bool ConfirmationText()
        {
            return _txtConfirmationText.Displayed;
        }

        public void ClickDataPackageLinkInDescription()
        {
            _lnkDataPackagesInDescription.Click();
        }

        public void ClickOnDataPackages()
        {
            //_lnkDataPackages.Click();
            _driver.DriverInstance().ClickAndWait(_lnkDataPackages,WaitTime.LongWaitTime);
        }

        public void SearchDataPackage(string packageName = "")
        {
            ClickOnDataPackages();
            _txtSearchDataPackageName.WaitForElementIsVisible(TimeoutInSeconds.DefaultTimeout);
            if (packageName == null)
            {
                _txtSearchDataPackageName.ClearAndEnterText(FileRepository.DataPackageName);
            }
            else if (packageName != null)
            {
                //packageName = packageName + Utilities.CurrentSystemDate();
                FileRepository.DataPackageName = packageName;
                _txtSearchDataPackageName.ClearAndEnterText(packageName);
            }
        }

        public string GetStatusOfDataPackage()
        {
            return _txtStatus.Text;
        }

        public void DownloadDataFile()
        {
            IWebElement _lnkDwnFile = _driver.FindElement(By.XPath($"//p[text()= '{FileRepository.DataPackageName}']/following::td/child::button"));
            _lnkDwnFile.Click();
        }

        public void ClickDataPackage(string packageName = "")
        {
            if (packageName == null)
            {
                packageName = FileRepository.DataPackageName;
            }
            IWebElement _clickDataPackageFile = _driver.FindElement(By.XPath($"//p[normalize-space()='{packageName}']"));
            _clickDataPackageFile.Click();
        }

        public void ClickLink(string linkName)
        {
            IWebElement _clickLinkName = _driver.FindElement(By.XPath($"//span[text()='{linkName}']"));
            _clickLinkName.WaitForElementIsVisible(TimeoutInSeconds.DefaultTimeout);
            //_clickLinkName.Click();
            _driver.DriverInstance().ClickAndWait(_clickLinkName, WaitTime.LongWaitTime);
        }

        public void ClickDeletePackageConfirmation()
        {
            try
            {
                _btnConfirmationDeletePackage.WaitForElementIsVisible(TimeoutInSeconds.DefaultTimeout);
                _driver.DriverInstance().ClickAndWait(_btnConfirmationDeletePackage, WaitTime.LongWaitTime);
            }
            catch (OpenQA.Selenium.StaleElementReferenceException ex)
            {
                _btnConfirmationDeletePackage.WaitForElementIsVisible(TimeoutInSeconds.DefaultTimeout);
                _driver.DriverInstance().ClickAndWait(_btnConfirmationDeletePackage,WaitTime.LongWaitTime);    

            }
        }

        public string VerifyConfirmationText()
        {
            return _txtDeletePackageConfirmation.Text;
        }

    }
}
