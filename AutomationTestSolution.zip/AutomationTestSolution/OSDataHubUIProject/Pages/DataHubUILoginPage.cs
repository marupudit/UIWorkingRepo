﻿using OpenQA.Selenium;
using TestFramework.Driver;
using TestFramework.Extensions;

namespace SpecFlowProjectNUnit.Pages
{
    public interface IDataHubUILoginPage
    {
        void ClickLink(string linkText);
        void ClickLogin();
        void EnterLoginCredentails(string userName, string password);
        string GetPageTitle();
        void SuccessfulLogin();
    }

    public class DataHubUILoginPage : IDataHubUILoginPage
    {
        private readonly IDriverWait _driver;
        public DataHubUILoginPage(IDriverWait driver)
        {
            _driver = driver;
        }
        /// <summary>
        /// Defining the page objects/ elements that I need to interact on webpage
        /// </summary>
        private IWebElement _txtUserName => _driver.FindElement(By.Id("signInName"));
        private IWebElement _txtPassword => _driver.FindElement(By.Id("password"));
        private IWebElement _btnSignIn => _driver.FindElement(By.Id("next"));

        /// <summary>
        /// Creating the actions/Methods that I need to perform on webpage
        /// <summary>
        /// 
        public void EnterLoginCredentails(string userName, string password)
        {
            _txtUserName.WaitForElementIsVisible(TimeoutInSeconds.ExtendedTimeout);
            _txtUserName.ClearAndEnterText(userName);
            _txtPassword.ClearAndEnterText(password);
        }

        public void ClickLogin() => _btnSignIn.Click();

        public void SuccessfulLogin()
        {
            _driver.DriverInstance().ClickAndWait(_btnSignIn, WaitTime.LongWaitTime);
        }

        public void ClickLink(string linkText)
        {
            IWebElement _linkElement = _driver.FindElement(By.LinkText(linkText));
            _linkElement.Click();
        }

        public string GetPageTitle()
        {
            return _driver.WindowTitle();
        }
    }
}
