﻿using OpenQA.Selenium;
using OSDataHubUIProject.Data.JsonDataTemplate;
using OSBaseAutoFramework.Helpers;
using TestFramework.Driver;
using TestFramework.Extensions;

namespace OSDataHubUIProject.Pages
{
    public interface ICreateANewRecipePage
    {
        void ClickAddDataPackage();
        void ClickAddRuleOrGroup(string filterToClick);
        void ClickApplyFilter();
        void ClickApplyFilter(string toFilter);
        void CreateANewRecipe();
        void EnterAttributeValue(string attributeValue);
        void EnterDescription(string recipeDescription);
        void EnterRecipeName(string recipeName);
        void ExpandSelectedTheme(string themeName);
        void ExpandThemeOrFeature(string toExpand);
        void SelectAttribute(string attributeName);
        void SelectOperator(string operatorName);
        void SelectTheme(string themeName);
        void SelectThemeOrFeature(string toSelect);
        bool VerifyRecipeCreated();
        string VerifySelectedTheme();
    }

    public class CreateANewRecipePage : ICreateANewRecipePage
    {
        private readonly IDriverWait _driver;
        public CreateANewRecipePage(IDriverWait driver)
        {
            _driver = driver;
        }
        /// <summary>
        /// Defining the page objects/ elements that I need to interact on webpage
        /// </summary>
        /// 

        private IWebElement _txtRecipeName => _driver.FindElement(By.Id("recipe-editor-name-input"));

        private IWebElement _txtRecipeDescription => _driver.FindElement(By.Id("recipeDescription"));

        private IWebElement _btnAddRecipeDescription => _driver.FindElement(By.XPath("//span[normalize-space()='Add description']"));

        private IWebElement _btnAddARecipeDescription => _driver.FindElement(By.XPath("//span[normalize-space()='Add a description']"));

        private IWebElement _btnCreateRecipe => _driver.FindElement(By.XPath("//span[normalize-space()='Create recipe']"));

        private IWebElement _txtSearchRecipe => _driver.FindElement(By.Id("search"));

        private IWebElement _txtSelectedTheme => _driver.FindElement(By.XPath("//span[@class='MuiTypography-root MuiTypography-caption']"));

        private IWebElement _btnAddDataPackage => _driver.FindElement(By.XPath("//span[normalize-space()='Add data package']"));

        private IWebElement _btnExpandAttributeList => _driver.FindElement(By.XPath("//button[@title='Open']"));

        private IWebElement _txtInputAttributeName => _driver.FindElement(By.XPath("//input[@aria-label='Field for Rule 1 in Main Group']"));

        private IWebElement _btnExpandOperatorList => _driver.FindElement(By.XPath("//div[@role='button']"));

        private IWebElement _txtInputAttributeValue => _driver.FindElement(By.XPath("//input[@aria-label='Value for Rule 1 in Main Group']"));

        private IWebElement _btnApplyFilter => _driver.FindElement(By.XPath("//span[normalize-space()='Apply filter']"));
        private IWebElement _lnkCreateRecipe => _driver.FindElement(By.XPath($"//span[normalize-space()='Create a new recipe']"));

        public void EnterRecipeName(string recipeName)
        {
            recipeName = recipeName + Utilities.CurrentSystemDate();
            FileRepository.RecipeName = recipeName.ToString();
            _txtRecipeName.ClearAndEnterText(recipeName);
        }

        public void EnterDescription(string recipeDescription)
        {
            _btnAddARecipeDescription.WaitForElementIsVisible(TimeoutInSeconds.DefaultTimeout);
            _btnAddARecipeDescription.Click();
            _txtRecipeDescription.ClearAndEnterText(recipeDescription);
            _btnAddRecipeDescription.Click();
        }

        public void SelectTheme(string themeName)
        {
            IWebElement _btnThemeElementId = _driver.FindElement(By.XPath($"(//input[@type='checkbox'])[{ThemeElementIdLocation(themeName)}]"));
            _btnThemeElementId.Click();
        }

        public void ExpandSelectedTheme(string themeName)
        {
            IWebElement _btnExpandThemeElementId = _driver.FindElement(By.XPath($"(//*[name()='title'][contains(text(),'expand')])[{ThemeElementIdLocation(themeName)}]"));
            _btnExpandThemeElementId.Click();
        }

        private string ThemeElementIdLocation(string themeName)
        {
            string elementLocation = "";
            switch (themeName)
            {
                case "Address":
                    elementLocation = "1";
                    break;
                case "Administrative and Statistical Units":
                    elementLocation = "2";
                    break;
                case "Buildings":
                    elementLocation = "3";
                    break;
                case "Geographical Names":
                    elementLocation = "4";
                    break;
                case "Land":
                    elementLocation = "5";
                    break;
                case "Land Use":
                    elementLocation = "6";
                    break;
                case "Structures":
                    elementLocation = "7";
                    break;
                case "Transport":
                    elementLocation = "8";
                    break;
                case "Water":
                    elementLocation = "9";
                    break;
                default:
                    elementLocation = "null";
                    break;
            }
            return elementLocation;
        }

        public void CreateANewRecipe()
        {
            _btnCreateRecipe.Click();
            _lnkCreateRecipe.WaitForElementIsVisible(TimeoutInSeconds.ExtendedTimeout);
        }

        public bool VerifyRecipeCreated()
        {
            SearchForNewlyCreatedRecipe();
            string elementId = string.Format("//h2[normalize-space()='{0}']", FileRepository.RecipeName);
            IWebElement _btnThemeElementId = _driver.FindElement(By.XPath(elementId));
            return _btnThemeElementId.Displayed;
        }

        public string VerifySelectedTheme()
        {
            return _txtSelectedTheme.Text;
        }

        public void ClickAddDataPackage()
        {
            SearchForNewlyCreatedRecipe();
            _btnAddDataPackage.Click();
        }

        private void SearchForNewlyCreatedRecipe()
        {
            _txtSearchRecipe.WaitForElementIsVisible(TimeoutInSeconds.ExtendedTimeout);
            _txtSearchRecipe.SendKeys(OpenQA.Selenium.Keys.LeftShift + OpenQA.Selenium.Keys.Home + OpenQA.Selenium.Keys.Space);
            _txtSearchRecipe.ClearAndEnterText(FileRepository.RecipeName);
        }

        public void SelectThemeOrFeature(string toSelect)
        {
            IWebElement _btnSelectThemeElementId = _driver.FindElement(By.XPath($"//span[text()='{toSelect}']/parent::div/parent::span/parent::button/preceding::input[@type='checkbox'][1]"));
            _btnSelectThemeElementId.Click();
        }

        public void ExpandThemeOrFeature(string toExpand)
        {
            IWebElement _btnExpandThemeElementId = _driver.FindElement(By.XPath($"//span[text()='{toExpand}']/parent::div/parent::span/parent::button/following-sibling::button/child::span//*[name()='svg']"));
            _btnExpandThemeElementId.Click();
        }

        public void ClickApplyFilter(string toFilter)
        {
            IWebElement _btnFilterElementId = _driver.FindElement(By.XPath($"//span[text()='{toFilter}']/parent::div/parent::span/parent::button/following-sibling::button/child::span//*[name()='svg']"));
            _btnFilterElementId.Click();
        }

        public void ClickAddRuleOrGroup(string filterToClick)
        {
            IWebElement _btnFilterRuleOrGroup = _driver.FindElement(By.XPath($"//span[normalize-space()='{filterToClick}']"));
            _btnFilterRuleOrGroup.Click();
        }

        public void SelectAttribute(string attributeName)
        {
            _btnExpandAttributeList.Click();
            _txtInputAttributeName.ClearAndEnterText(attributeName);
            _txtInputAttributeName.SendKeys(Keys.Down);
            _txtInputAttributeName.SendKeys(Keys.Enter);
        }

        public void SelectOperator(string operatorName)
        {
            _btnExpandOperatorList.Click();
            IWebElement _btnSelectOperatorValue = _driver.FindElement(By.XPath($"//ul[@class='MuiList-root MuiMenu-list MuiList-padding']//li[text()='{operatorName}']"));
            _btnSelectOperatorValue.Click();
        }

        public void EnterAttributeValue(string attributeValue)
        {
            _txtInputAttributeValue.ClearAndEnterText(attributeValue);
        }

        public void ClickApplyFilter()
        {
            _btnApplyFilter.Click();
        }
    }
}
