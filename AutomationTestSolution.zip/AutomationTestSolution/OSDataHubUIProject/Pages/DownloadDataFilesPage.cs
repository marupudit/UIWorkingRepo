﻿using OpenQA.Selenium;
using OSBaseAutoFramework.Helpers;
using PGSAEndToEndBaseProject.Config;
using Serilog;
using System.IO.Compression;
using System.Reflection;
using TestFramework.Config;
using TestFramework.Driver;

namespace OSDataHubUIProject.Pages
{
    public interface IDownloadDataFilesPage
    {
        void DownloadDataFilesFromDataHub(string dataFileName);
        int GetAvailableDownloadFilesCount();
        void MoveTheFilesDownloadedFiles(string scenarioNumber, string dataFileName);
        void UnzippedTheDownloadedFiles(string scenarioNumber, string dataFileName);
    }

    public class DownloadDataFilesPage : IDownloadDataFilesPage
    {
        private readonly IDriverWait _driver;
        private readonly DefaultSettings _testSettings;
        public DownloadDataFilesPage(IDriverWait driver, DefaultSettings testsettings)
        {
            _driver = driver;
            _testSettings = testsettings;
        }
        /// <summary>
        /// Defining the page objects/ elements that I need to interact on webpage
        /// </summary>
        int _lnkDownloadFilesCount => _driver.FindElements(By.XPath("//div/child::a/child::p")).Count();

        public int GetAvailableDownloadFilesCount()
        {
            return _lnkDownloadFilesCount - 1;//Excluding header value so -1.
        }

        public void DownloadDataFilesFromDataHub(string dataFileName)
        {
            IWebElement _lnkDownloadFile = _driver.FindElement(By.XPath($"//div/child::a/child::p[text()='{dataFileName}']"));                                          
            _lnkDownloadFile.Click();
            string fileDownloading = string.Format(@Settings.ChromeDownloadLocation, "*.crdownload");
            bool targetExists = true;
            int counter = 0;
            do
            {
                targetExists = System.IO.File.Exists(fileDownloading);
                Thread.Sleep(2000);
            } while (targetExists || counter >= 1200);
            string sourceZipPath = string.Format(@Settings.ChromeDownloadLocation, dataFileName);
            bool sourceFileDownloaded = false;
            counter = 0;
            do
            {
                sourceFileDownloaded = System.IO.File.Exists(sourceZipPath);
                Thread.Sleep(2000);
            } while (!sourceFileDownloaded || counter >= 1200);
        }

        public void UnzippedTheDownloadedFiles(string scenarioNumber, string dataFileName)
        {
            var paths = SetAndCreateTargetFolder(scenarioNumber, dataFileName);
            try
            {
                ZipFile.ExtractToDirectory(paths.Item1, paths.Item2);
            }
            catch (Exception ex)
            {
                Log.Error($"Error while unzipping the file:{dataFileName}, as part of {scenarioNumber} with exception {ex}");
            }
        }

        public void MoveTheFilesDownloadedFiles(string scenarioNumber, string dataFileName)
        {
            var paths = SetAndCreateTargetFolder(scenarioNumber, dataFileName);
            var dest = Path.Combine(paths.Item2, dataFileName);
            try
            {
                File.Copy(paths.Item1, dest, true);
                File.Delete(paths.Item1);
            }
            catch (Exception ex)
            {
                Log.Error($"Error while copying the file:{dataFileName}, as part of {scenarioNumber} with exception {ex}");
            }
        }

        private Tuple<string, string> SetAndCreateTargetFolder(string scenarioNumber, string dataFileName)
        {
            string sourceZipPath = string.Format(Settings.ChromeDownloadLocation, dataFileName);
            var targetOutputPath = Path.Combine(Settings.DownloadedDataFiles);
            Console.WriteLine("Base path: "+ Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
            Directory.SetCurrentDirectory(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)+targetOutputPath);
            Console.WriteLine("The system path is :" + Directory.GetCurrentDirectory());
            targetOutputPath = $"{Utilities.CurrentSystemDate()}\\{scenarioNumber}";
            bool targetExists = System.IO.Directory.Exists(targetOutputPath);
            if (!targetExists)
            {
                System.IO.Directory.CreateDirectory(targetOutputPath);
            }
            Tuple<string, string> paths = new Tuple<string, string>(sourceZipPath, targetOutputPath);
            return paths;
        }
    }
}
