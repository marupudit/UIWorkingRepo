﻿using AventStack.ExtentReports;
using OpenQA.Selenium;
using TestFramework.Config;

namespace TestFramework.Driver
{
    public interface IDriverWait
    {
        IWebElement FindElement(By elementLocator);
        IEnumerable<IWebElement> FindElements(By elementLocator);
        string WindowTitle();
        IWebDriver DriverInstance();
        MediaEntityModelProvider CaptureScreenshotAndReturnModel(string Name);
        DefaultSettings testSettings();
    }
}