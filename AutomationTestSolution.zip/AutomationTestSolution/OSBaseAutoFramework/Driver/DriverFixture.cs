﻿using AventStack.ExtentReports;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Safari;
using TestFramework.Config;

namespace TestFramework.Driver
{
    public class DriverFixture : IDriverFixture, IDisposable
    {
        public IWebDriver Driver { get; }
        public readonly DefaultSettings _testSettings;
        public DriverFixture(DefaultSettings testSettings)
        {
            _testSettings = testSettings;
            Driver = GetWebDriver();
            Driver.Navigate().GoToUrl(_testSettings.ApplicationUrl);
            Driver.Manage().Window.Maximize();
        }

        private IWebDriver GetWebDriver()
        {
            return _testSettings.BrowserType switch
            {
                BrowserType.Chrome => new ChromeDriver(),
                BrowserType.Firefox => new FirefoxDriver(),
                BrowserType.Safari => new SafariDriver(),
                _ => new ChromeDriver()
            };
        }

        public void Dispose()
        {
            //Handling using the Hook
            //Driver.Quit();
        }
    }

    public enum BrowserType
    {
        Chrome,
        Firefox,
        Safari,
        EdgeChromium
    }



}
