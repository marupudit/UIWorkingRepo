﻿using AventStack.ExtentReports;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System.Threading;
using System.Xml.Linq;
using TestFramework.Config;
using TestFramework.Extensions;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium;
using AventStack.ExtentReports;

namespace TestFramework.Driver
{
    public class DriverWait : IDriverWait
    {
        private readonly IDriverFixture _driverFixture;
        private readonly DefaultSettings _testSettings;
        private readonly Lazy<WebDriverWait> _webDriverWait;

        public DriverWait(IDriverFixture driverFixture, DefaultSettings testsettings)
        {
            _driverFixture = driverFixture;
            _testSettings = testsettings;
            _webDriverWait = new Lazy<WebDriverWait>(GetWaitDriver);
        }

        public IWebElement FindElement(By elementLocator)
        {
            return _webDriverWait.Value.Until(_ => _driverFixture.Driver.FindElement(elementLocator));
        }

        public IEnumerable<IWebElement> FindElements(By elementLocator)
        {
            return _webDriverWait.Value.Until(_ => _driverFixture.Driver.FindElements(elementLocator));
        }

        public string WindowTitle()
        {
            return _driverFixture.Driver.Title;
        }

        public IWebDriver DriverInstance()
        {
            return _driverFixture.Driver;
        }

        private WebDriverWait GetWaitDriver()
        {
            return new(_driverFixture.Driver, timeout: TimeSpan.FromSeconds(_testSettings.TimeoutInterval ?? 30))
            {
                PollingInterval = TimeSpan.FromSeconds(_testSettings.TimeoutInterval ?? 1)
            };
        }

        public MediaEntityModelProvider CaptureScreenshotAndReturnModel(string Name)
        {
            var screenshot = ((ITakesScreenshot)_driverFixture.Driver).GetScreenshot().AsBase64EncodedString;

            return MediaEntityBuilder.CreateScreenCaptureFromBase64String(screenshot, Name).Build();
        }

        public DefaultSettings testSettings()
        {
            return _testSettings;
        }

    }
}
