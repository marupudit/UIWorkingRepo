﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using Serilog;

namespace TestFramework.Extensions
{
    public static class WebElementExtension
    {
        public static void SelectDropDownByText(this IWebElement element, string text) 
        {
            var select = new SelectElement(element);
            select.SelectByText(text);
        }

        public static void SelectDropDownByValue(this IWebElement element, string value)
        {
            var select = new SelectElement(element);
            select.SelectByValue(value);
        }

        public static void SelectDropDownByIndes(this IWebElement element, int index)
        {
            var select = new SelectElement(element);
            select.SelectByIndex(index);
        }

        public static void ClearAndEnterText(this IWebElement element,string value) 
        {
            element.Clear();
            element.SendKeys(value);
        }

        public static void Click (this IWebElement element)
        {
            element.Click();
        }

        public static bool WaitForElementIsVisible(this IWebElement element, int timeoutInSeconds)
        {
            var result = false;
            var timeout = 0;
            while (result == false)
            {
                if (timeout >= timeoutInSeconds)
                {
                    break;
                }

                Thread.Sleep(Timeouts.OneSecond);
                timeout += 1;
                try
                {
                    result = element.Displayed;
                }
                catch (Exception ex)
                {
                    Log.Warning("Exception message :"+ ex.Message);    
                }                
            }
            return result;
        }

        public static void ClickAndWait(this IWebDriver driver, IWebElement element, TimeSpan? timeout = null)
        {
            if (timeout == null)
            {
                timeout = TimeSpan.FromSeconds(30);
            }
            Click(element);
            driver.Manage().Timeouts().ImplicitWait = (TimeSpan)timeout;
        }
    }
}
