﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestFramework.Extensions
{
    public static class Timeouts
    {
        public const int DefaultTimeout = 60000;
        public const int ExtendedTimeout = 240000;
        public const int ControlTimeout = 10000;
        public const int OneSecond = 1000;
    }

    public static class TimeoutInSeconds
    {
        public const int DefaultTimeout = 60;
        public const int ExtendedTimeout = 240;
        public const int ControlTimeout = 10;
        public const int OneSecond = 1;
    }

    public static class WaitTime
    {
        public static TimeSpan ShortWaitTime { get; set; } = TimeSpan.FromSeconds(5);

        public static TimeSpan MediumWaitTime { get; set; } = TimeSpan.FromSeconds(10);

        public static TimeSpan AverageWaitTime { get; set; } = TimeSpan.FromSeconds(15);

        public static TimeSpan LongWaitTime { get; set; } = TimeSpan.FromSeconds(30);

        public static TimeSpan VeryLongWaitTime { get; set; } = TimeSpan.FromSeconds(60);
    }
}
