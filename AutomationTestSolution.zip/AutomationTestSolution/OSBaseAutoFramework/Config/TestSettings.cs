﻿using Newtonsoft.Json;

namespace PGSAEndToEndBaseProject.Config
{
    [JsonObject("testSettings")]
    public class TestSettings
    {        
        [JsonProperty("seriInfoLogFileLocation")]
        public string SeriInfoLogFileLocation { get; set; }

        [JsonProperty("seriErrorLogFileLocation")]
        public string SeriErrorLogFileLocation { get; set; }

        [JsonProperty("seriLogRollingInterval")]
        public string SeriLogRollingInterval { get; set; }

        [JsonProperty("seriLogDefault")]
        public string SeriLogDefault { get; set; }

        [JsonProperty("extentReportPath")]
        public string ExtentReportPath { get; set; }

        [JsonProperty("datapackageInfoCsv")]
        public string DatapackageInfoCsv { get; set; }

        [JsonProperty("datapackageInfoJson")]
        public string DatapackageInfoJson { get; set; }

        [JsonProperty("downloadedDataFiles")]
        public string DownloadedDataFiles { get; set; }

        [JsonProperty("datapackageInfoRoot")]
        public string DatapackageInfoRoot { get; set; }

        [JsonProperty("chromeDownloadLocation")]
        public string ChromeDownloadLocation { get; set; }       

    }
}
