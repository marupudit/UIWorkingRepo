﻿namespace PGSAEndToEndBaseProject.Config
{
    public class Settings
    {

        public static string SeleniumGridUrl { get; set; }
        public static bool UseDockerGrid { get; set; }

        public static string SeriInfoLogFileLocation { get; set; }
        public static string SeriErrorLogFileLocation { get; set; }

        public static string SeriLogRollingInterval { get; set; }

        public static string SeriLogDefault { get; set; }

        public static string ExtentReportPath { get; set; }

        public static string DatapackageInfoCsv { get; set; }
        public static string DatapackageInfoJson { get; set; }
        public static string DownloadedDataFiles { get; set; }
        public static string DatapackageInfoRoot { get; set; }
        public static string ChromeDownloadLocation { get; set; }

    }
}
