﻿using TestFramework.Driver;

namespace TestFramework.Config
{
    public class DefaultSettings
    {
        public BrowserType BrowserType { get; set; }
        public Uri ApplicationUrl { get; set; }
        public float? TimeoutInterval { get; set; }
    }
}
