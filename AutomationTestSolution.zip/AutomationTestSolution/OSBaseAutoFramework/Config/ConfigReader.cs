﻿using Microsoft.Extensions.Configuration;
using PGSAEndToEndBaseProject.Config;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace TestFramework.Config
{
    public class ConfigReader
    {

        public static DefaultSettings ReadConfig()
        {
            var configFile = File.ReadAllText(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + "/AppSettings.json");

            var jsonSerializeOptions = new JsonSerializerOptions()
            {
                PropertyNameCaseInsensitive = true
            };

            jsonSerializeOptions.Converters.Add(new JsonStringEnumConverter());

            return JsonSerializer.Deserialize<DefaultSettings>(configFile, jsonSerializeOptions);
        }

        private IConfigurationRoot configurationRoot;

        public ConfigReader()
        {
            var builder = new ConfigurationBuilder()
                 .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("Appsettings.json");
            configurationRoot = builder.Build();
        }

        public void SetFrameworkSettings()
        {
            Settings.SeriInfoLogFileLocation = configurationRoot.GetSection("SeriLogging").Get<TestSettings>().SeriInfoLogFileLocation;
            Settings.SeriErrorLogFileLocation = configurationRoot.GetSection("SeriLogging").Get<TestSettings>().SeriErrorLogFileLocation;
            Settings.SeriLogRollingInterval = configurationRoot.GetSection("SeriLogging").Get<TestSettings>().SeriLogRollingInterval;
            Settings.SeriLogDefault = configurationRoot.GetSection("SeriLogging").Get<TestSettings>().SeriLogDefault;

            Settings.ExtentReportPath = configurationRoot.GetSection("ExtentReports").Get<TestSettings>().ExtentReportPath;

            Settings.DownloadedDataFiles = configurationRoot.GetSection("DataFilesLocation").Get<TestSettings>().DownloadedDataFiles;
            Settings.DatapackageInfoCsv = configurationRoot.GetSection("DataFilesLocation").Get<TestSettings>().DatapackageInfoCsv;
            Settings.DatapackageInfoJson = configurationRoot.GetSection("DataFilesLocation").Get<TestSettings>().DatapackageInfoJson;
            Settings.DatapackageInfoRoot = configurationRoot.GetSection("DataFilesLocation").Get<TestSettings>().DatapackageInfoRoot;

            Settings.ChromeDownloadLocation = configurationRoot.GetSection("DataFilesLocation").Get<TestSettings>().ChromeDownloadLocation;
        }



    }
}
