﻿using TechTalk.SpecFlow;

namespace OSBaseAutoFramework.Helpers
{
    public static class  Utilities
    {
        public static string CurrentSystemDate()
        {
            DateTime dateTime = DateTime.UtcNow.Date;
            string dT = DateTime.Now.ToString("yyyy_MM_dd");
            return dT;
        }
        public static string CurrentSystemDateWithHr()
        {
            DateTime dateTime = DateTime.UtcNow.Date;
            string dT = DateTime.Now.ToString("yyyy_MM_dd_HH");
            return dT;
        }

        public static List<string> ConvertTableToList(Table inputTable)
        {
            List<string> convertedList = new List<string>();
            foreach (var tablerow in inputTable.Rows)
            {
                string text = tablerow["FileNames"];
                convertedList.Add(tablerow["FileNames"]);
            }
            return convertedList;
        }

        public static Dictionary<string, string> ConvertTableToDictionary(Table inputTable)
        {
            Dictionary<string, string> convertedList = new Dictionary<string, string>();
            foreach (var tablerow in inputTable.Rows)
            {
                string key = tablerow["Key"];
                string value = tablerow["Value"];
                convertedList.Add(key, value);
            }
            return convertedList;
        }
    }
}
